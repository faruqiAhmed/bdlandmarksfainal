

import SwiftUI

struct HikeBadge: View {
    var name: String
    var body: some View {
        Image("turtlerock")
        
    }
}

struct HikeBadge_Previews: PreviewProvider {
    static var previews: some View {
        HikeBadge(name: "Preview Testing")
    }
}
