//
//  Homepage.swift
//  Landmarks
//
//  Created by imac os on 2/27/20.
//  Copyright © 2020 Apple. All rights reserved.
//

import SwiftUI

struct Homepage: View {
    @State var Currentpage = 0
    @EnvironmentObject var userData: UserData
    var body: some View {
         
        NavigationView{
        VStack{
            ZStack{
                
                if Currentpage == 0{
                    Image("Group 11").resizable().frame(height: 350).cornerRadius(20).padding()
                }
                else if Currentpage == 0 {
                    Image("Group 12").resizable().frame(height: 350).cornerRadius(20).padding()
                } else{
                    Image("Group 13").resizable().frame(height: 350).cornerRadius(20).padding()
                }
                
                
                
            }
            
            pagControl( current: Currentpage)
            HStack{
                Button ( action: {
                    if self.Currentpage != 0{
                        self.Currentpage -= 1
                    }
                }) {
                    Text("Previous").padding(15)
                }.background(Color.orange)
                .cornerRadius(20)
                    .foregroundColor(.white)
                Button ( action: {
                    if self.Currentpage < 3{
                        self.Currentpage += 1
                    }
                }) {
                    Text("Next").padding(15)
                }.background(Color.orange)
                .cornerRadius(20)
                    .foregroundColor(.white)
            }.padding()
       NavigationLink(destination: CategoryHome()) {
              // Text("Press on me")
             
               Text("SKIP")
       
             }.buttonStyle(PlainButtonStyle())
            
        }.animation(.spring())
        }
    }
}

struct Homepage_Previews: PreviewProvider {
    static var previews: some View {
        Homepage().environmentObject(UserData())
    }
}
struct pagControl: UIViewRepresentable {
    var current = 0
    func makeUIView(context: UIViewRepresentableContext<pagControl>) -> UIPageControl {
        let page = UIPageControl()
        page.currentPageIndicatorTintColor = .red
        page.numberOfPages = 3
        page.currentPageIndicatorTintColor = .blue
        return page
    }
    func updateUIView(_ uiView: UIPageControl, context: UIViewRepresentableContext<pagControl>) {
        uiView.currentPage = current
    }
}
