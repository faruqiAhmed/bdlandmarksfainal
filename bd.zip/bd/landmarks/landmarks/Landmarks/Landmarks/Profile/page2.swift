//
//  page2.swift
//  Landmarks
//
//  Created by imac os on 2/27/20.
//  Copyright © 2020 Apple. All rights reserved.
//

import SwiftUI

struct page2: View {
    @State private var isActive: Bool = false
    @State private var selection: Int? = nil
    var body: some View {
        NavigationView {
          VStack{
               
            NavigationLink(destination: Image("Group 11"), tag: 1, selection: self.$selection){
                Image("logo-2")
            }
            
            NavigationLink(destination: Image("Group 13"), tag: 2, selection: self.$selection){
                Text("")
            }
            NavigationLink(destination: page(), tag: 3, selection: self.$selection){
                           Text("")
                       }
            Button("skip"){
                //self.isActive = true
                self.selection = 3
            }
              
               
             }
        }
        .navigationBarTitle(Text("Featured"))
            
    }
}

struct page2_Previews: PreviewProvider {
    static var previews: some View {
        page2()
    }
}
