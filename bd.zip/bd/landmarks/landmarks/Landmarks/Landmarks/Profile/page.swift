//
//  page.swift
//  Landmarks
//
//  Created by imac os on 2/26/20.
//  Copyright © 2020 Apple. All rights reserved.
//

import SwiftUI

struct page: View {

  var body: some View {

 NavigationView {
    VStack{

        NavigationLink(destination: CategoryHome()) {
                  // Text("Press on me")

                    Image("Onboarding 41")

                  }.buttonStyle(PlainButtonStyle())




       }
  }
  .navigationBarTitle(Text("Featured"))

   }
}

struct page_Previews: PreviewProvider {
   static var previews: some View {
       page().environmentObject(UserData())
   }
}
