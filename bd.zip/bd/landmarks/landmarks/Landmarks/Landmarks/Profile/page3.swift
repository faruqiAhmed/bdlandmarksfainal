//
//  page3.swift
//  Landmarks
//
//  Created by imac os on 2/27/20.
//  Copyright © 2020 Apple. All rights reserved.
//

import SwiftUI

struct page3: View {
    var body: some View {
       NavigationView {
         VStack{
              
             NavigationLink(destination: page()) {
                        // Text("Press on me")
                       
                         Image("Onboarding 51")
                 
                       }.buttonStyle(PlainButtonStyle())
             
             
             
              
            }
       }
       .navigationBarTitle(Text("Featured"))
    }
}

struct page3_Previews: PreviewProvider {
    static var previews: some View {
        page3()
    }
}
